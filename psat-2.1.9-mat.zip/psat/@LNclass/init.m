function a = init(a)

a.con = [];
a.n = 0;
a.fr = [];
a.to = [];
a.vfr = [];
a.vto = [];
a.Y = [];
a.Bp = [];
a.Bpp = [];
a.p = 0;
a.q = 0;
a.u = [];
a.no_build_y = 0;
