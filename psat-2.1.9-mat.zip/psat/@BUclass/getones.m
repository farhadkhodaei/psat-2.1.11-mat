function u = getones(a)

u = ones(a.n,1);
