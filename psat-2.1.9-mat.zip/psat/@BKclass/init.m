function a = init(a)

a.con = [];
a.n = 0;
a.bus = [];
a.line = [];
a.t1 = [];
a.t2 = [];
a.u = [];
a.time = inf;
