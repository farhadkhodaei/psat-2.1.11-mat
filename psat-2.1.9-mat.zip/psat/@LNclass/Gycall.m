function Gycall(a)

global DAE

DAE.Gy = build_gy(a);
