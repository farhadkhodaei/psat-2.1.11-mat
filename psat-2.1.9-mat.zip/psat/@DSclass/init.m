function a = init(a)

a.con = [];
a.n = 0;
a.syn = [];
a.delta_HP = [];
a.omega_HP = [];
a.delta_IP = [];
a.omega_IP = [];
a.delta_LP = [];
a.omega_LP = [];
a.delta_EX = [];
a.omega_EX = [];
a.delta = [];
a.omega = [];
a.pm = [];
a.u = [];
