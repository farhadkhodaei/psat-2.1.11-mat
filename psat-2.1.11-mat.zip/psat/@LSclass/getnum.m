function n = getnum(a)

if a.n
  n = sum(a.u);
else
  n = 0;
end
