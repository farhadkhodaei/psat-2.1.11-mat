function a = init(a)

a.con = [];
a.n = 0;
a.bus1 = [];
a.bus2 = [];
a.v1 = [];
a.v2 = [];
a.u = [];
