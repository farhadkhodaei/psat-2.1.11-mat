function p = base(p)

global Bus Settings

if ~p.n, return, end

