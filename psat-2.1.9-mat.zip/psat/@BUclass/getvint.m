function u = getvint(a,idx)

u = a.int(round(idx)) + a.n;
