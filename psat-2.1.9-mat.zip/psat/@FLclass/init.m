function a = init(a)

a.con = [];
a.n = 0;
a.bus = [];
a.vbus = [];
a.a0 = [];
a.x = [];
a.u = [];
a.dw = [];
