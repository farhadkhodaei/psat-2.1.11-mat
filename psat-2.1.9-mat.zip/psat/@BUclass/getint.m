function u = getint(a,idx)

u = a.int(round(idx));
