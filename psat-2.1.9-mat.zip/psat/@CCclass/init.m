function a = init(a)

a.con = [];
a.n = 0;
a.bus = [];
a.vbus = [];
a.q1 = [];
a.q = [];
a.u = [];
