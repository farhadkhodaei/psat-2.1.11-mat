function a = init(a)

a.con = [];
a.n = 0;
a.int = [];
a.a = [];
a.v = [];
a.Pl = [];
a.Ql = [];
a.Pg = [];
a.Qg = [];
a.names = cell(0,0);
a.island = [];
