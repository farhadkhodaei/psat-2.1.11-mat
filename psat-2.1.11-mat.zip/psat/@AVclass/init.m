function a = init(a)

a.con = [];
a.n = 0;
a.syn = [];
a.bus = [];
a.vbus = [];
a.vref = [];
a.vref0 = [];
a.vr1  = [];
a.vr2 = [];
a.vr3 = [];
a.vfd = [];
a.vm = [];
a.vf = [];
a.u = [];
