function a = init(a)

a.con = [];
a.n = 0;
a.exc = [];
a.syn = [];
a.svc = [];
a.q = [];
a.vref = [];
a.cac  = [];
a.Vs = [];
a.dVsdQ = [];
a.u = [];
