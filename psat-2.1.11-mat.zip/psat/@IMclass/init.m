function a = init(a)

a.con = [];
a.n = 0;
a.bus = [];
a.vbus = [];
a.dat = [];
a.slip = [];
a.e1r = [];
a.e1m = [];
a.e2r = [];
a.e2m = [];
a.z = [];
a.u = [];
