function display(a)

disp(struct(a))
