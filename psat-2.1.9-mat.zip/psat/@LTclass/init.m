function a = init(a)

a.con = [];
a.n = 0;
a.bus1 = [];
a.bus2 = [];
a.v1 = [];
a.v2 = [];
a.vr = [];
a.mc = [];
a.md = [];
a.mold = [];
a.delay = [];
a.u = [];

