function windup(a)

fm_windup(a.Vs,a.con(:,8),a.con(:,9),'td');
