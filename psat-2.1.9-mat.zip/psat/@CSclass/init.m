function a = init(a)

a.con = [];
a.n = 0;
a.bus = [];
a.vbus = [];
a.wind = [];
a.omega_t = [];
a.omega_m = [];
a.gamma = [];
a.e1r = [];
a.e1m = [];
a.u = [];
