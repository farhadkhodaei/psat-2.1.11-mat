function a = init(a)

a.con = [];
a.n = 0;
a.bus = [];
a.vbus = [];
a.dat = [];
a.vref = [];
a.btx1 = [];
a.id = [];
a.iq = [];
a.u = [];
