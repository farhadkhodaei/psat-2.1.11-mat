function a = init(a)

a.con = [];
a.n = 0;
a.bus = cell(0,0);
a.names = cell(0,0);
a.int = [];
a.slack = [];
