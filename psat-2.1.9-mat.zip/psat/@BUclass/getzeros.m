function u = getzeros(a)

u = zeros(a.n,1);
