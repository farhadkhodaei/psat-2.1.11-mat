function a = init(a)

a.con = [];
a.n = 0;
a.bus = [];
a.vbus = [];
a.dat = [];
a.wind = [];
a.omega_m = [];
a.theta_p = [];
a.vref = [];
a.pwa = [];
a.idr = [];
a.iqr = [];
a.u = [];
